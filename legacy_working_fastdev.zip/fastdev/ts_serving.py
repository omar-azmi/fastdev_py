from asyncio import Future
from subprocess import Popen
from urllib.parse import urljoin
import requests
from fastapi.responses import JSONResponse, Response
from .config import CWSD, PORT, PROJ_DIR
from .utils import qoute

BUILD_SERVER_PORT = 3000  # the port on which `deno_lts_esbuild.ts` listens for build requests
build_server_loaded_promise = Future()
build_server_path = PROJ_DIR.joinpath("./builders/deno_lts_esbuild.ts")
build_server_callback_path = "/build_server_loaded"
build_server_callback = f"http://localhost:{PORT}{build_server_callback_path}"
build_server_url = f"http://localhost:{BUILD_SERVER_PORT}"
build_server_process = Popen(f"deno run -A {qoute(build_server_path)} --port={BUILD_SERVER_PORT} --callback={qoute(build_server_callback)}", cwd=CWSD)


async def serve_ts(url_path: str):
	print(f"SERVE TS URL: {url_path}")
	await build_server_loaded_promise
	print(f"SERVE TS URL: {url_path}")
	file_abspath = CWSD.joinpath(url_path)
	output_js_response = requests.post(urljoin(build_server_url, "compile"), json={
		"path": str(file_abspath),
		"config": {"minify": False},
		"plugins": ["solid"],
		"plugins_config": dict(),
	})
	if output_js_response is None:
		return JSONResponse(
			{"error": "failed to transpile and bundle the requested file."},
			status_code=503
		)
	return Response(output_js_response.content, status_code=output_js_response.status_code, media_type="text/javascript")
